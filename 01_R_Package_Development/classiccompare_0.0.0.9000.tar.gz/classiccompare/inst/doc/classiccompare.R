## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(classiccompare)

## -----------------------------------------------------------------------------
base <- data.frame(id = c("A", "B", "C"), x = c(1, 2, 3), y = c("a", "b", "c"))
comp <- data.frame(id = c("C", "A", "D"), x = c(3, 1.5, 9), y = c("c", "a", "d"))

classic_compare(base, comp)

## -----------------------------------------------------------------------------
classic_compare(base, comp, id = "id", listall = TRUE)

## -----------------------------------------------------------------------------
classic_compare(data.frame(x = 100), data.frame(x = 100.4),
                method = "percent", criterion = 0.5)

## -----------------------------------------------------------------------------
res <- classic_compare(base, comp, id = "id")
sysinfo(res)
sysinfo_decode(sysinfo(res))

## -----------------------------------------------------------------------------
stopifnot_example <- tryCatch(
  stopifnot(sysinfo(res) == 0L),
  error = function(e) "datasets differ — this would normally halt a QC script"
)
stopifnot_example

## -----------------------------------------------------------------------------
classic_compare(base, comp, id = "id", var = "x")

## -----------------------------------------------------------------------------
classic_compare(base, comp, id = "id", novalues = TRUE, listall = TRUE)

